﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webproject.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Banks",
                columns: table => new
                {
                    BankId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Bankname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Banks", x => x.BankId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    userid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BankId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.userid);
                    table.ForeignKey(
                        name: "FK_Users_Banks_BankId",
                        column: x => x.BankId,
                        principalTable: "Banks",
                        principalColumn: "BankId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    AccountId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Balance = table.Column<double>(type: "float", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.AccountId);
                    table.ForeignKey(
                        name: "FK_Accounts_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "userid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Banks",
                columns: new[] { "BankId", "Bankname", "City" },
                values: new object[,]
                {
                    { 1, "Arab Islamic Bank", "Jenin" },
                    { 2, "Bank of Palestine.", "Ramallh" },
                    { 3, "Al Quds Bank.", "Jenin" },
                    { 4, "Palestine Investment Bank.", "Tullkarm" },
                    { 5, "The National Bank TNB..", "Tullkarm" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "userid", "BankId", "password", "username" },
                values: new object[,]
                {
                    { 1, 1, "123", "Abrar" },
                    { 2, 2, "987", "ansam" },
                    { 3, 4, "235", "yara" },
                    { 4, 3, "333", "malak" },
                    { 5, 4, "154", "Aseel" },
                    { 6, 5, "432", "mohammed" },
                    { 7, 1, "345", "anas" }
                });

            migrationBuilder.InsertData(
                table: "Accounts",
                columns: new[] { "AccountId", "Balance", "UserId" },
                values: new object[,]
                {
                    { 1, 1500.0, 1 },
                    { 2, 2000.0, 2 },
                    { 3, 2500.0, 3 },
                    { 4, 3000.0, 4 },
                    { 5, 3500.0, 5 },
                    { 6, 4000.0, 6 },
                    { 7, 4000.0, 7 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Accounts_UserId",
                table: "Accounts",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_BankId",
                table: "Users",
                column: "BankId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Banks");
        }
    }
}
