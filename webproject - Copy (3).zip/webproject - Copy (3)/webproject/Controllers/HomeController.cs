﻿
using Microsoft.AspNetCore.Mvc;

using System.Diagnostics;
using webproject.Models;

namespace webproject.Controllers
{
    public class HomeController : Controller
    {
        private Bank2context context { get; set; }

        public HomeController(Bank2context ctx) => context = ctx;

        public IActionResult Index()
        {
  

        var Bb = context.Banks.ToList();

            return View(Bb);
        }

      

    }
}