using Microsoft.AspNetCore.Mvc;
using webproject.Models;



namespace webproject.Controllers
{
    public class BankController : Controller
    {
        private Bank2context context { get; set; }

        public BankController(Bank2context ctx) => context = ctx;

        public IActionResult Getbanks()
        {
            var B = context.Banks.ToList();

            return View(B);
        }
        public IActionResult search(string searchkey)
        {
            var bank = context.Banks.Where(b => b.Bankname.Contains(searchkey)).ToList();

            return View("Getbanks", bank);
        }
        [HttpGet]
        public IActionResult login()
        {


            return View();
        }




        [HttpPost]
        public IActionResult login(string username, string password)
           
        {
            User Test = context.Users.FirstOrDefault(u => u.username == username && u.password == password);
            if (Test == null)
            {
               
                return View();
            }
            HttpContext.Session.SetInt32("key", 1);

            return RedirectToAction("Account", Test);


        }
    
        [HttpGet]
        public IActionResult SignUp()
        {
            ViewBag.bb = context.Banks.ToList();
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(User uu)
        {

           


                context.Users.Add(uu);
                context.SaveChanges();
                return RedirectToAction("creat");
            

            return View("signup");
        }
        public IActionResult Account(User ui)
        {

            Account account = context.Accounts.FirstOrDefault(a => a.userid == (ui.userid));
            if (account == null)
            {
                return View("login");
            }

            return View(account);
        }
        public IActionResult creat()
        {
            if (HttpContext.Session.GetInt32("key") == null)//////////// 
            {
                return View("LogIn");
            }
                Account A = new Account();

            return View("Account", A);
        }
        [HttpGet]
        public IActionResult Add()
        {

            return View();
        }


    }
   
}

