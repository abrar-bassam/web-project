﻿using Microsoft.EntityFrameworkCore;

namespace webproject.Models
{
        public class Bank2context : DbContext
        {
            public Bank2context(DbContextOptions<Bank2context> options)
                : base(options)
            { }

        public DbSet<Bank> Banks { get; set; } 
        public DbSet<Account> Accounts { get; set; } 
        public DbSet<User> Users { get; set; } 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
            {

            modelBuilder.Entity<Bank>().HasData(

                   new Bank
                   {
                       BankId = 1,
                       Bankname = "Arab Islamic Bank",
                       City = "Jenin",

                   },
             new Bank
             {
                 BankId = 2,
                 Bankname = "Bank of Palestine.",
                 City = "Ramallh",

             },

             new Bank
             {
                 BankId = 3,
                 Bankname = "Al Quds Bank.",
                 City = "Jenin",

             },
              new Bank
              {
                  BankId = 4,
                  Bankname = "Palestine Investment Bank.",
                  City = "Tullkarm",

              },

              new Bank
              {
                  BankId = 5,
                  Bankname = "The National Bank TNB..",
                  City = "Tullkarm",

              }

              );

            modelBuilder.Entity<User>().HasData(

                new User
                {
                    userid = 1,
                    username = "Abrar",
                    password = "123",
                    BankId = 1,
                },
               
                new User
                {
                    userid = 2,
                    username = "ansam",
                    password = "987",
                    BankId = 2,
                },

                new User
                {
                    userid = 3,
                    username = "yara",
                    password = "235",
                    BankId = 4,
                },
                new User
                {
                    userid = 4,
                    username = "malak",
                    password = "333",
                    BankId = 3,
                },
                new User
                {
                    userid = 5,
                    username = "Aseel",
                    password = "154",
                    BankId = 4,
                },
                new User
                {
                    userid = 6,
                    username = "mohammed",
                    password = "432",
                    BankId = 5,
                },
                new User
                {
                    userid = 7,
                    username = "anas",
                    password = "345",
                    BankId = 1,
                }


        );


            modelBuilder.Entity<Account>().HasData(
                
                new Account
                {
                    AccountId = 1,
                   
                    Balance = 1500.00,
                    userid = 1,
                   
                },
                new Account
                {
                    AccountId = 2,
                    
                    Balance = 2000.00,
                    userid = 2,
                   
                },
                new Account
                {
                    AccountId = 3,
                   
                    Balance = 2500.00,
                    userid = 3,
                   
                },
                new Account
                {
                    AccountId = 4,
                   
                    Balance = 3000.00,
                    userid = 4,
                   
                },
                new Account
                {
                    AccountId = 5,
                   
                    Balance = 3500.00,
                    userid = 5,
                   
                },
                new Account
                {
                    AccountId = 6,
                   
                    Balance = 4000.00,
                    userid = 6,
                   
                },
                 new Account
                 {
                     AccountId = 7,
                  
                     Balance = 4000.00,
                     userid = 7,
                    
                 }
            );





            }
        }
    }


