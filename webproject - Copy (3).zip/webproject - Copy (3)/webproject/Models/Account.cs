﻿namespace webproject.Models
{
    public class Account
    {
            public int AccountId { get; set; }
            public double Balance { get; set; }
            public int userid { get; set; }
        public User User { get; set; }
            
        }
    }


