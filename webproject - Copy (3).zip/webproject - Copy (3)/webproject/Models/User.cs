﻿using System.ComponentModel.DataAnnotations;

namespace webproject.Models
{
    public class User
    {
        
            [Required(ErrorMessage = "Please enter  your id")]
            [Key]
            public int userid { set; get; }
        public string username { set; get; } 

        public string password { set; get; } 
            public int BankId { set; get; }
        public Bank Bank { set; get; }

        }

    }


