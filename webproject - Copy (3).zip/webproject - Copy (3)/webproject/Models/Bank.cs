﻿using System.ComponentModel.DataAnnotations;
namespace webproject.Models
{

    
    public class Bank
    {
        [Key]
        [Required(ErrorMessage = "Please enter a Bankid.")]

        public int BankId { get; set; }
        [Required(ErrorMessage = "Please enter a Bankname.")]

        public string Bankname { get; set; } 
        public string City { get; set; } 

    }
}